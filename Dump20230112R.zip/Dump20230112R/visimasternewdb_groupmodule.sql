-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `groupmodule`
--

DROP TABLE IF EXISTS `groupmodule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupmodule` (
  `GroupModuleId` mediumint NOT NULL AUTO_INCREMENT,
  `GroupId` smallint DEFAULT NULL,
  `ModuleId` smallint DEFAULT NULL,
  `HasAccess` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`GroupModuleId`),
  KEY `FK_groupmodule_groupid_idx` (`GroupId`) /*!80000 INVISIBLE */,
  KEY `FK_groupmodule_moduleid_idx` (`ModuleId`),
  CONSTRAINT `FK_groupmodule_groupid` FOREIGN KEY (`GroupId`) REFERENCES `group` (`GroupId`),
  CONSTRAINT `FK_groupmodule_moduleid` FOREIGN KEY (`ModuleId`) REFERENCES `module` (`ModuleId`)
) ENGINE=InnoDB AUTO_INCREMENT=376 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupmodule`
--

LOCK TABLES `groupmodule` WRITE;
/*!40000 ALTER TABLE `groupmodule` DISABLE KEYS */;
INSERT INTO `groupmodule` VALUES (1,1,63,_binary ''),(2,2,63,_binary ''),(3,3,63,_binary '\0'),(4,1,64,_binary ''),(5,2,64,_binary '\0'),(6,3,64,_binary '\0'),(7,1,65,_binary ''),(8,2,65,_binary '\0'),(9,3,65,_binary '\0'),(10,1,97,_binary ''),(11,2,97,_binary ''),(12,3,97,_binary '\0'),(13,1,66,_binary ''),(14,2,66,_binary '\0'),(15,3,66,_binary '\0'),(16,1,67,_binary ''),(17,2,67,_binary '\0'),(18,3,67,_binary '\0'),(19,1,68,_binary ''),(20,2,68,_binary '\0'),(21,3,68,_binary '\0'),(22,1,69,_binary ''),(23,2,69,_binary '\0'),(24,3,69,_binary '\0'),(25,1,70,_binary ''),(26,2,70,_binary '\0'),(27,3,70,_binary '\0'),(28,1,71,_binary ''),(29,2,71,_binary '\0'),(30,3,71,_binary '\0'),(31,1,72,_binary ''),(32,2,72,_binary '\0'),(33,3,72,_binary '\0'),(34,1,73,_binary ''),(35,2,73,_binary '\0'),(36,3,73,_binary '\0'),(37,1,74,_binary ''),(38,2,74,_binary ''),(39,3,74,_binary '\0'),(40,1,75,_binary ''),(41,2,75,_binary ''),(42,3,75,_binary '\0'),(43,1,76,_binary ''),(44,2,76,_binary ''),(45,3,76,_binary '\0'),(46,1,77,_binary ''),(47,2,77,_binary ''),(48,3,77,_binary '\0'),(49,1,78,_binary ''),(50,2,78,_binary '\0'),(51,3,78,_binary '\0'),(52,1,79,_binary ''),(53,2,79,_binary '\0'),(54,3,79,_binary '\0'),(55,1,80,_binary ''),(56,2,80,_binary ''),(57,3,80,_binary '\0'),(58,1,81,_binary ''),(59,2,81,_binary ''),(60,3,81,_binary '\0'),(61,1,82,_binary ''),(62,2,82,_binary '\0'),(63,3,82,_binary '\0'),(64,1,83,_binary '\0'),(65,2,83,_binary '\0'),(66,3,83,_binary '\0'),(67,1,84,_binary ''),(68,2,84,_binary ''),(69,3,84,_binary '\0'),(70,1,101,_binary ''),(71,2,101,_binary ''),(72,3,101,_binary ''),(73,1,102,_binary ''),(74,2,102,_binary ''),(75,3,102,_binary ''),(76,1,103,_binary ''),(77,2,103,_binary ''),(78,3,103,_binary ''),(79,1,104,_binary ''),(80,2,104,_binary ''),(81,3,104,_binary ''),(82,1,105,_binary ''),(83,2,105,_binary ''),(84,3,105,_binary ''),(85,1,106,_binary ''),(86,2,106,_binary ''),(87,3,106,_binary ''),(88,1,85,_binary ''),(89,2,85,_binary ''),(90,3,85,_binary '\0'),(91,1,86,_binary ''),(92,2,86,_binary ''),(93,3,86,_binary '\0'),(94,1,87,_binary ''),(95,2,87,_binary ''),(96,3,87,_binary ''),(97,1,88,_binary ''),(98,2,88,_binary ''),(99,3,88,_binary ''),(100,1,89,_binary ''),(101,2,89,_binary ''),(102,3,89,_binary ''),(103,1,90,_binary '\0'),(104,2,90,_binary ''),(105,3,90,_binary '\0'),(106,1,91,_binary ''),(107,2,91,_binary ''),(108,3,91,_binary '\0'),(109,1,92,_binary ''),(110,2,92,_binary ''),(111,3,92,_binary '\0'),(112,1,93,_binary ''),(113,2,93,_binary ''),(114,3,93,_binary '\0'),(115,1,94,_binary ''),(116,2,94,_binary ''),(117,3,94,_binary '\0'),(118,1,95,_binary ''),(119,2,95,_binary '\0'),(120,3,95,_binary '\0'),(121,1,96,_binary ''),(122,2,96,_binary ''),(123,3,96,_binary '\0'),(124,1,98,_binary ''),(125,2,98,_binary ''),(126,3,98,_binary '\0'),(127,1,99,_binary ''),(128,2,99,_binary ''),(129,3,99,_binary '\0'),(130,1,100,_binary ''),(131,2,100,_binary ''),(132,3,100,_binary '\0'),(133,1,107,_binary ''),(134,2,107,_binary ''),(135,3,107,_binary '\0'),(136,1,108,_binary ''),(137,2,108,_binary ''),(138,3,108,_binary '\0'),(139,1,109,_binary ''),(140,2,109,_binary ''),(141,3,109,_binary '\0'),(142,1,112,_binary ''),(143,2,112,_binary '\0'),(144,3,112,_binary '\0'),(145,1,110,_binary ''),(146,2,110,_binary '\0'),(147,3,110,_binary '\0'),(148,1,111,_binary ''),(149,2,111,_binary '\0'),(150,3,111,_binary '\0'),(151,1,113,_binary ''),(152,2,113,_binary ''),(153,3,113,_binary '\0'),(154,1,114,_binary ''),(155,2,114,_binary ''),(156,3,114,_binary '\0'),(157,1,115,_binary ''),(158,2,115,_binary ''),(159,3,115,_binary '\0'),(160,1,116,_binary ''),(161,2,116,_binary ''),(162,3,116,_binary '\0'),(163,1,117,_binary ''),(164,2,117,_binary ''),(165,3,117,_binary '\0'),(166,1,118,_binary ''),(167,2,118,_binary ''),(168,3,118,_binary '\0'),(169,1,119,_binary ''),(170,2,119,_binary ''),(171,3,119,_binary '\0'),(172,1,120,_binary ''),(173,2,120,_binary ''),(174,3,120,_binary '\0'),(175,1,121,_binary ''),(176,2,121,_binary ''),(177,3,121,_binary '\0'),(178,1,122,_binary ''),(179,2,122,_binary ''),(180,3,122,_binary '\0'),(181,1,123,_binary ''),(182,2,123,_binary ''),(183,3,123,_binary '\0'),(184,1,124,_binary ''),(185,2,124,_binary ''),(186,3,124,_binary ''),(187,1,125,_binary ''),(188,2,125,_binary ''),(189,3,125,_binary '\0'),(190,1,126,_binary ''),(191,2,126,_binary ''),(192,3,126,_binary '\0'),(193,1,127,_binary ''),(194,2,127,_binary ''),(195,3,127,_binary '\0'),(196,1,128,_binary ''),(197,2,128,_binary ''),(198,3,128,_binary '\0'),(199,1,129,_binary ''),(200,2,129,_binary ''),(201,3,129,_binary '\0'),(202,1,130,_binary ''),(203,2,130,_binary ''),(204,3,130,_binary '\0'),(205,1,131,_binary ''),(206,2,131,_binary ''),(207,3,131,_binary '\0'),(208,1,132,_binary ''),(209,2,132,_binary ''),(210,3,132,_binary '\0'),(211,1,133,_binary ''),(212,2,133,_binary ''),(213,3,133,_binary '\0'),(214,1,134,_binary ''),(215,2,134,_binary ''),(216,3,134,_binary '\0'),(217,1,135,_binary ''),(218,2,135,_binary ''),(219,3,135,_binary '\0'),(220,1,136,_binary ''),(221,2,136,_binary ''),(222,3,136,_binary '\0'),(223,1,137,_binary ''),(224,2,137,_binary ''),(225,3,137,_binary '\0'),(226,1,138,_binary ''),(227,2,138,_binary ''),(228,3,138,_binary '\0'),(229,1,139,_binary ''),(230,2,139,_binary ''),(231,3,139,_binary '\0'),(232,1,140,_binary ''),(233,2,140,_binary ''),(234,3,140,_binary '\0'),(235,1,141,_binary ''),(236,2,141,_binary ''),(237,3,141,_binary '\0'),(238,1,142,_binary ''),(239,2,142,_binary ''),(240,3,142,_binary '\0'),(241,1,143,_binary ''),(242,2,143,_binary ''),(243,3,143,_binary ''),(244,1,144,_binary ''),(245,2,144,_binary ''),(246,3,144,_binary ''),(247,1,145,_binary ''),(248,2,145,_binary ''),(249,3,145,_binary ''),(250,1,146,_binary ''),(251,2,146,_binary ''),(252,3,146,_binary '\0'),(253,1,147,_binary ''),(254,2,147,_binary ''),(255,3,147,_binary '\0'),(256,1,148,_binary ''),(257,2,148,_binary ''),(258,3,148,_binary '\0'),(259,1,149,_binary ''),(260,2,149,_binary ''),(261,3,149,_binary '\0'),(262,1,150,_binary ''),(263,2,150,_binary ''),(264,3,150,_binary '\0'),(265,1,151,_binary ''),(266,2,151,_binary ''),(267,3,151,_binary '\0'),(268,1,152,_binary ''),(269,2,152,_binary ''),(270,3,152,_binary '\0'),(271,1,153,_binary ''),(272,2,153,_binary ''),(273,3,153,_binary '\0'),(274,1,154,_binary ''),(275,2,154,_binary ''),(276,3,154,_binary '\0'),(277,1,155,_binary ''),(278,2,155,_binary ''),(279,3,155,_binary '\0'),(280,1,156,_binary ''),(281,2,156,_binary ''),(282,3,156,_binary '\0'),(283,1,157,_binary ''),(284,2,157,_binary ''),(285,3,157,_binary '\0'),(286,1,158,_binary ''),(287,2,158,_binary ''),(288,3,158,_binary '\0'),(289,1,159,_binary ''),(290,2,159,_binary ''),(291,3,159,_binary '\0'),(292,1,160,_binary ''),(293,2,160,_binary ''),(294,3,160,_binary '\0'),(295,1,161,_binary ''),(296,2,161,_binary ''),(297,3,161,_binary '\0'),(298,1,162,_binary ''),(299,2,162,_binary ''),(300,3,162,_binary '\0'),(301,1,163,_binary '\0'),(302,2,163,_binary '\0'),(303,3,163,_binary '\0'),(304,1,164,_binary '\0'),(305,2,164,_binary '\0'),(306,3,164,_binary '\0'),(307,1,165,_binary ''),(308,2,165,_binary ''),(309,3,165,_binary '\0'),(310,1,166,_binary ''),(311,2,166,_binary ''),(312,3,166,_binary '\0'),(313,1,167,_binary '\0'),(314,2,167,_binary '\0'),(315,3,167,_binary '\0'),(316,1,168,_binary ''),(317,2,168,_binary ''),(318,3,168,_binary '\0'),(319,1,169,_binary ''),(320,2,169,_binary ''),(321,3,169,_binary '\0'),(322,1,170,_binary '\0'),(323,2,170,_binary '\0'),(324,3,170,_binary '\0'),(325,1,171,_binary '\0'),(326,2,171,_binary '\0'),(327,3,171,_binary '\0'),(328,1,172,_binary ''),(329,2,172,_binary ''),(330,3,172,_binary '\0'),(331,1,173,_binary ''),(332,2,173,_binary ''),(333,3,173,_binary '\0'),(334,1,174,_binary ''),(335,2,174,_binary ''),(336,3,174,_binary '\0'),(337,1,175,_binary '\0'),(338,2,175,_binary '\0'),(339,3,175,_binary '\0'),(340,1,176,_binary '\0'),(341,2,176,_binary '\0'),(342,3,176,_binary '\0'),(343,1,211,_binary '\0'),(344,2,211,_binary '\0'),(345,3,211,_binary '\0'),(346,1,212,_binary ''),(347,2,212,_binary ''),(348,3,212,_binary '\0'),(349,1,213,_binary ''),(350,2,213,_binary ''),(351,3,213,_binary '\0'),(352,1,214,_binary ''),(353,2,214,_binary ''),(354,3,214,_binary '\0'),(355,1,215,_binary ''),(356,2,215,_binary ''),(357,3,215,_binary '\0'),(358,1,NULL,_binary ''),(359,2,NULL,_binary ''),(360,3,NULL,_binary ''),(361,1,102,_binary ''),(362,2,102,_binary ''),(363,3,102,_binary ''),(364,1,105,_binary ''),(365,2,105,_binary ''),(366,3,105,_binary ''),(367,1,NULL,_binary ''),(368,2,NULL,_binary ''),(369,3,NULL,_binary ''),(370,1,104,_binary ''),(371,2,104,_binary ''),(372,3,104,_binary ''),(373,1,NULL,_binary ''),(374,2,NULL,_binary ''),(375,3,NULL,_binary '\0');
/*!40000 ALTER TABLE `groupmodule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:46
