-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `plc_configuration`
--

DROP TABLE IF EXISTS `plc_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plc_configuration` (
  `ConfigurationID` smallint NOT NULL AUTO_INCREMENT,
  `JobNo` varchar(100) NOT NULL,
  `PLCID` smallint NOT NULL,
  `HardwareDevice` varchar(45) NOT NULL,
  `HardwareDeviceNo` smallint NOT NULL,
  `Parameter` varchar(45) NOT NULL,
  `Value` int NOT NULL,
  `LastUpdatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`JobNo`,`PLCID`,`HardwareDevice`,`HardwareDeviceNo`,`Parameter`),
  UNIQUE KEY `ConfigurationID_UNIQUE` (`ConfigurationID`),
  KEY `FK_plc_configuration_plcno_plc_idx` (`PLCID`),
  KEY `FK_plc_configuration_jobNo_job_idx` (`JobNo`),
  CONSTRAINT `FK_plc_configuration_jobno_job` FOREIGN KEY (`JobNo`) REFERENCES `job` (`JobNo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_plc_configuration_plcno_plc` FOREIGN KEY (`PLCID`) REFERENCES `plc` (`PLCID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='configuration setting for each job id';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plc_configuration`
--

LOCK TABLES `plc_configuration` WRITE;
/*!40000 ALTER TABLE `plc_configuration` DISABLE KEYS */;
INSERT INTO `plc_configuration` VALUES (1,'Auto',1,'Camera',1,'Position',0,'2023-01-11 06:24:23'),(2,'Auto',1,'Camera',2,'Position',0,'2023-01-11 06:24:23'),(5,'Auto',1,'Disk',1,'Speed',0,'2023-01-11 06:28:22'),(6,'Auto',1,'Ejection',1,'Ontime',0,'2023-01-11 06:28:22'),(7,'Auto',1,'Ejection',1,'Position',0,'2023-01-11 06:28:22'),(3,'Auto',1,'Motor',1,'MotorPosition',0,'2023-01-11 06:24:23'),(4,'Auto',1,'Motor',1,'MotorPositionWrite',0,'2023-01-11 06:24:23');
/*!40000 ALTER TABLE `plc_configuration` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:48
