-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `measure_data_controlparameters`
--

DROP TABLE IF EXISTS `measure_data_controlparameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `measure_data_controlparameters` (
  `MeasureDataS_Control_EQID` int NOT NULL AUTO_INCREMENT,
  `JobNo` varchar(100) NOT NULL,
  `CamID` smallint NOT NULL,
  `DataSource` varchar(100) NOT NULL,
  `DataType` varchar(100) NOT NULL,
  `TemplateName` varchar(100) NOT NULL,
  `Data` varchar(100) NOT NULL,
  `parameterName` varchar(100) DEFAULT NULL,
  `paravalue` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`MeasureDataS_Control_EQID`),
  KEY `FK_CAMID_JOBNO_idx` (`JobNo`,`CamID`,`DataSource`,`DataType`,`TemplateName`,`Data`),
  CONSTRAINT `FK_CAMID_JOBNO` FOREIGN KEY (`JobNo`, `CamID`, `DataSource`, `DataType`, `TemplateName`, `Data`) REFERENCES `measure_data` (`JobNo`, `CamID`, `DataSource`, `DataType`, `TemplateName`, `Data`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1072 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='lines, circles and points data\n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `measure_data_controlparameters`
--

LOCK TABLES `measure_data_controlparameters` WRITE;
/*!40000 ALTER TABLE `measure_data_controlparameters` DISABLE KEYS */;
INSERT INTO `measure_data_controlparameters` VALUES (1012,'12',1,'AdvancedHexCircle','Circle','aaa','415.75','ObjectColor','dark'),(1013,'12',1,'AdvancedHexCircle','Circle','aaa','415.75','Threshold','100'),(1014,'RDN',1,'AdvancedHexCircle','Circle','abc','463.75','ObjectColor','dark'),(1015,'RDN',1,'AdvancedHexCircle','Circle','abc','463.75','Threshold','100'),(1016,'rtgt',1,'PeakLine','Line','rgte','8','Smooth','1'),(1017,'rtgt',1,'PeakLine','Line','rgte','8','ObjectColor','canny'),(1018,'rtgt',1,'PeakLine','Line','rgte','8','HighThreshold','40'),(1019,'rtgt',1,'PeakLine','Line','rgte','8','LowThreshold','20'),(1020,'rtgt',1,'PeakLine','Line','rgte','8','UnionMaxDistAbs','1'),(1021,'rtgt',1,'PeakLine','Line','rgte','8','UnionMaxDistRel','1'),(1022,'Try',1,'PeakLine','Line','ssd','8','Smooth','1'),(1023,'Try',1,'PeakLine','Line','ssd','8','ObjectColor','canny'),(1024,'Try',1,'PeakLine','Line','ssd','8','HighThreshold','40'),(1025,'Try',1,'PeakLine','Line','ssd','8','LowThreshold','20'),(1026,'Try',1,'PeakLine','Line','ssd','8','UnionMaxDistAbs','1'),(1027,'Try',1,'PeakLine','Line','ssd','8','UnionMaxDistRel','1'),(1028,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint6','Index','6'),(1029,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint6','ThresholdMin','30'),(1030,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint6','ThresholdMax','255'),(1031,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint6','FillUpMin','1'),(1032,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint6','FillUpMax','100'),(1033,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint6','ErodRegion','1'),(1034,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint6','SelectShapeMin','1'),(1035,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint6','SelectShapeMax','1000000'),(1036,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint6','OpeningCircle','1'),(1037,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint6','ClosingCircle','1'),(1038,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint8','Index','8'),(1039,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint8','ThresholdMin','30'),(1040,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint8','ThresholdMax','255'),(1041,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint8','FillUpMin','1'),(1042,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint8','FillUpMax','100'),(1043,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint8','ErodRegion','1'),(1044,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint8','SelectShapeMin','1'),(1045,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint8','SelectShapeMax','1000000'),(1046,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint8','OpeningCircle','1'),(1047,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint8','ClosingCircle','1'),(1048,'Try',1,'ThreadStartLine','Line','ssd','20','RemoveDust','5'),(1049,'Try',1,'ThreadStartLine','Line','ssd','20','Smooth','4'),(1050,'Try',1,'ThreadStartLine','Line','ssd','20','EdgeMinimumDistance','5'),(1051,'Try',1,'ThreadStartLine','Line','ssd','20','EdgeMaximumDistance','10'),(1052,'Try',1,'ThreadStartLine','Line','ssd','20','MinLineLength','5'),(1053,'Try',1,'ThreadStartLine','Line','ssd','20','SetMinimumDistance','4'),(1054,'Try',1,'ThreadStartLine','Line','ssd','20','AngleTolerance','2'),(1055,'Try',1,'ThreadStartLine','Line','ssd','20','ThreaAngle','1'),(1056,'Try',1,'ThreadStartLine','Line','ssd','20','RefLineSeqID','0'),(1057,'Try',1,'ThreadStartLine','Line','ssd','21','RemoveDust','5'),(1058,'Try',1,'ThreadStartLine','Line','ssd','21','Smooth','4'),(1059,'Try',1,'ThreadStartLine','Line','ssd','21','EdgeMinimumDistance','5'),(1060,'Try',1,'ThreadStartLine','Line','ssd','21','EdgeMaximumDistance','10'),(1061,'Try',1,'ThreadStartLine','Line','ssd','21','MinLineLength','5'),(1062,'Try',1,'ThreadStartLine','Line','ssd','21','SetMinimumDistance','4'),(1063,'Try',1,'ThreadStartLine','Line','ssd','21','AngleTolerance','2'),(1064,'Try',1,'ThreadStartLine','Line','ssd','21','ThreaAngle','1'),(1065,'Try',1,'ThreadStartLine','Line','ssd','21','RefLineSeqID','0'),(1066,'Try3',1,'PeakLine','Line','Trd','3','Smooth','1'),(1067,'Try3',1,'PeakLine','Line','Trd','3','ObjectColor','canny'),(1068,'Try3',1,'PeakLine','Line','Trd','3','HighThreshold','40'),(1069,'Try3',1,'PeakLine','Line','Trd','3','LowThreshold','20'),(1070,'Try3',1,'PeakLine','Line','Trd','3','UnionMaxDistAbs','1'),(1071,'Try3',1,'PeakLine','Line','Trd','3','UnionMaxDistRel','1');
/*!40000 ALTER TABLE `measure_data_controlparameters` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:46
