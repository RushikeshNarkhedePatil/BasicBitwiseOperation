-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `parameterconfiguration`
--

DROP TABLE IF EXISTS `parameterconfiguration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parameterconfiguration` (
  `parameterconfigurationid` int NOT NULL AUTO_INCREMENT,
  `Type` varchar(45) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Value` varchar(45) NOT NULL,
  `LastupdatedDate` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CamID` varchar(45) NOT NULL DEFAULT 'all',
  PRIMARY KEY (`parameterconfigurationid`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parameterconfiguration`
--

LOCK TABLES `parameterconfiguration` WRITE;
/*!40000 ALTER TABLE `parameterconfiguration` DISABLE KEYS */;
INSERT INTO `parameterconfiguration` VALUES (1,'LineToLine','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(2,'TemplateMatching','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(3,'HorizontalLine','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(4,'Diameter','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(5,'HorizontalLine','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(6,'GenerateLine','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(7,'MeasurePair','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(8,'MeasureArc','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(9,'Radius','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(10,'Angle','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(11,'PointToPoint','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(12,'LineIntersection','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(13,'Surface','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(14,'FFT','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(15,'FlashUsingThresholdID','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(16,'FlashUsingThresholdIDFlash','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(17,'FlashUsingThresholdOD','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(18,'FlashUsingThresholdODFlash','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(19,'HelixAngle','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(20,'ThreadAngle','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(21,'PitchHeight','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(22,'PitchDistance','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(23,'MajorDia','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(24,'MinorDia','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(25,'ThreadTappingCount','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(26,'Parllality','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(27,'PeakFromBase','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(28,'EdgeMinimumDistance','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(29,'EdgeMaximumDistance','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(30,'ScaledShape','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(31,'EllipseRadius','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(32,'DetectColor','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(33,'GrooveDiameter','ApplyErrorValue','0','2022-08-17 14:01:53','all'),(34,'Shapebase','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(35,'PCD','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(36,'PCD','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(37,'HolePresent','ApplyErrorValue','0','2022-08-16 14:42:37','all'),(38,'PeakDistance','ErrorValue','1','2022-08-16 14:42:37','all'),(39,'FlashUsingThresholdODCut','ApplyErrorValue','1','2022-08-16 14:42:37','all'),(40,'FlashUsingThresholdIDCut','ApplyErrorValue','1','2022-08-16 14:42:37','all');
/*!40000 ALTER TABLE `parameterconfiguration` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:45
