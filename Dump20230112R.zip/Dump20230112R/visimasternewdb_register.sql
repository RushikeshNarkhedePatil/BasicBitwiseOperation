-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register` (
  `registerSEQID` int NOT NULL AUTO_INCREMENT,
  `PLCID` smallint NOT NULL,
  `HardwareDevice` varchar(45) NOT NULL,
  `HardwareDeviceNo` smallint NOT NULL,
  `Parameter` varchar(45) NOT NULL,
  `Address` int NOT NULL,
  `LastUpdatedDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`registerSEQID`),
  KEY `registerPLCID_idx` (`PLCID`),
  CONSTRAINT `registerPLCID_FK` FOREIGN KEY (`PLCID`) REFERENCES `plc` (`PLCID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='register details used in software';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `register`
--

LOCK TABLES `register` WRITE;
/*!40000 ALTER TABLE `register` DISABLE KEYS */;
INSERT INTO `register` VALUES (109,1,'Camera',1,'ResultControl',0,'2022-12-07 03:52:37'),(110,1,'Camera',1,'IsRotary',0,'2022-12-07 03:52:37'),(111,1,'Camera',1,'Position',0,'2022-12-07 03:52:37'),(112,1,'Camera',1,'TriggerCount',0,'2022-12-07 03:52:37'),(113,1,'Camera',2,'ResultControl',0,'2022-12-07 03:52:37'),(114,1,'Camera',2,'IsRotary',0,'2022-12-07 03:52:37'),(115,1,'Camera',2,'Position',0,'2022-12-07 03:52:37'),(116,1,'Camera',2,'TriggerCount',0,'2022-12-07 03:52:37'),(117,1,'ResultR1',1,'ResultPartIndex',0,'2022-12-07 03:52:37'),(118,1,'ResultR1',1,'Result',0,'2022-12-07 03:52:37'),(119,1,'ResultR1',1,'ResultNOK',0,'2022-12-07 03:52:37'),(120,1,'Motor',1,'Forword',0,'2022-12-07 03:52:37'),(121,1,'Motor',1,'Reverse',0,'2022-12-07 03:52:37'),(122,1,'Motor',1,'MotorPosition',0,'2022-12-07 03:52:37'),(123,1,'Motor',1,'MotorPositionWrite',0,'2022-12-07 03:52:37'),(124,1,'Alarm',1,'OnOff',0,'2022-12-07 03:52:37'),(125,1,'Alarm',1,'Number',0,'2022-12-07 03:52:37'),(126,1,'Software',1,'Mode',0,'2022-12-07 03:52:37'),(127,1,'Software',1,'CoilAddress',3999,'2022-12-07 03:52:48'),(128,1,'Software',1,'OnOff',0,'2022-12-07 04:57:25'),(129,1,'Alarm',1,'PLCHandShake',0,'2022-12-07 03:52:37'),(130,1,'Alarm',1,'SoftwareHandShake',0,'2022-12-07 03:52:37'),(131,1,'Alarm',1,'AlaramNo',0,'2022-12-07 03:52:37'),(132,1,'ToggleEjection1',1,'Result',0,'2022-12-07 03:52:37'),(133,1,'ToggleEjection2',1,'Result',0,'2022-12-07 03:52:37'),(134,1,'Ejection',1,'OnOff',0,'2023-01-12 04:54:36'),(135,1,'Ejection',1,'Position',0,'2023-01-12 04:54:36'),(136,1,'Ejection',1,'Count',0,'2023-01-12 04:54:36'),(137,1,'Ejection',1,'Ontime',0,'2023-01-12 04:54:36'),(138,1,'Disk',1,'Speed',0,'2023-01-12 04:54:36'),(139,1,'Disk',1,'OnOff',0,'2023-01-12 04:54:36'),(140,1,'Disk',1,'Position',0,'2023-01-12 04:54:36'),(141,1,'Disk',1,'Reverse',0,'2023-01-12 04:54:36');
/*!40000 ALTER TABLE `register` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:48
