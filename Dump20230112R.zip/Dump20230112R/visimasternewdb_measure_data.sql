-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `measure_data`
--

DROP TABLE IF EXISTS `measure_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `measure_data` (
  `MeasureDataSEQID` int NOT NULL AUTO_INCREMENT,
  `JobNo` varchar(100) NOT NULL,
  `CamID` smallint NOT NULL,
  `DataSource` varchar(100) NOT NULL,
  `DataType` varchar(100) NOT NULL,
  `TemplateName` varchar(100) NOT NULL,
  `Data` varchar(100) NOT NULL,
  PRIMARY KEY (`JobNo`,`CamID`,`DataSource`,`DataType`,`TemplateName`,`Data`),
  UNIQUE KEY `MeasureDataSEQID_UNIQUE` (`MeasureDataSEQID`),
  KEY `MeasureData_JobNo_idx` (`JobNo`),
  KEY `MeasureData_CamID_idx` (`CamID`),
  CONSTRAINT `MeasureData_CamID` FOREIGN KEY (`CamID`) REFERENCES `camera` (`CamID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `MeasureData_JobNo` FOREIGN KEY (`JobNo`) REFERENCES `job` (`JobNo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='lines, circles and points data\n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `measure_data`
--

LOCK TABLES `measure_data` WRITE;
/*!40000 ALTER TABLE `measure_data` DISABLE KEYS */;
INSERT INTO `measure_data` VALUES (19,'12',1,'AdvancedHexCircle','Circle','aaa','415.75'),(44,'RDN',1,'Metrology','Circle','abc','0'),(45,'RDN',1,'Metrology','Circle','abc','1'),(46,'RDN',1,'Metrology','Circle','abc','2'),(47,'RDN',1,'AdvancedHexCircle','Circle','abc','463.75'),(49,'RN1',1,'Metrology','Circle','abcd','0'),(51,'rtgt',1,'Metrology','Circle','rgte','0'),(52,'rtgt',1,'Metrology','Line','rgte','1'),(53,'rtgt',1,'Metrology','Line','rgte','2'),(54,'rtgt',1,'StepLine','Line','rgte','1,2'),(55,'rtgt',1,'Metrology','Line','rgte','3'),(56,'rtgt',1,'Metrology','Line','rgte','4'),(57,'rtgt',1,'Metrology','Line','rgte','5'),(58,'rtgt',1,'StepLine','Line','rgte','4,5'),(59,'rtgt',1,'Metrology','Line','rgte','6'),(60,'rtgt',1,'Metrology','Line','rgte','7'),(61,'rtgt',1,'StepLine','Line','rgte','6,7'),(62,'rtgt',1,'PeakLine','Line','rgte','8'),(63,'rtgt',1,'MetrologyPoints','Point','rgte','Point58-55'),(64,'rtgt',1,'Metrology','Line','rgte','9'),(65,'rtgt',1,'Metrology','Line','rgte','10'),(66,'rtgt',1,'MetrologyPoints','Point','rgte','Point64-65'),(69,'Try',1,'StepLine','Line','ssd','0,1'),(72,'Try',1,'StepLine','Line','ssd','2,3'),(73,'Try',1,'Metrology','Line','ssd','4'),(74,'Try',1,'Metrology','Line','ssd','5'),(75,'Try',1,'MetrologyPoints','Point','ssd','Point74-73'),(76,'Try',1,'Metrology','Line','ssd','6'),(77,'Try',1,'Metrology','Line','ssd','7'),(78,'Try',1,'MetrologyPoints','Point','ssd','Point76-77'),(79,'Try',1,'PeakLine','Line','ssd','8'),(82,'Try',1,'StepLine','Line','ssd','9,10'),(83,'Try',1,'Metrology','Circle','ssd','11'),(84,'Try2',1,'Metrology','Circle','crl','0'),(86,'Try2',1,'Metrology','Circle','crl','2'),(87,'Try2',1,'Metrology','Circle','crl','3'),(88,'Try2',1,'Metrology','Circle','crl','4'),(89,'Try',1,'Metrology','Circle','ssd','12'),(90,'Try',1,'Metrology','Line','ssd','13'),(91,'Try',1,'Metrology','Line','ssd','14'),(92,'Try',1,'MetrologyPoints','Point','ssd','Point90-91'),(93,'Try',1,'Metrology','Line','ssd','15'),(95,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint6'),(96,'123',1,'Metrology','Line','square','0'),(97,'123',1,'Metrology','Line','square','1'),(98,'123',1,'Metrology','Line','square','2'),(99,'123',1,'Metrology','Line','square','3'),(100,'123',1,'MetrologyPoints','Point','square','Point98-99'),(101,'123',1,'MetrologyPoints','Point','square','Point96-97'),(102,'123',1,'MetrologyPoints','Point','square','Point96-98'),(103,'123',1,'MetrologyPoints','Point','square','Point99-97'),(104,'123',1,'Metrology','Line','square','4'),(105,'123',1,'Metrology','Line','square','5'),(106,'123',1,'AngleIntersectionLine','Line','square','4,5'),(107,'Try',1,'Metrology','Line','ssd','16'),(108,'Try',1,'Metrology','Line','ssd','17'),(109,'Try',1,'MetrologyPoints','Point','ssd','Point107-108'),(112,'Try',1,'AngleIntersectionLine','Line','ssd','18,19'),(114,'Try2',1,'MetrologyPoints','Point','crl','AreaCenterPoint8'),(115,'Try',1,'ThreadStartLine','Line','ssd','20'),(116,'Try',1,'ThreadStartLine','Line','ssd','21'),(117,'Try3',1,'Metrology','Circle','Trd','0'),(118,'Try3',1,'Metrology','Line','Trd','1'),(119,'Try3',1,'Metrology','Line','Trd','2'),(120,'Try3',1,'StepLine','Line','Trd','1,2'),(121,'Try3',1,'PeakLine','Line','Trd','3'),(122,'Try3',1,'Metrology','Line','Trd','4'),(123,'Try3',1,'Metrology','Line','Trd','5'),(124,'Try3',1,'MetrologyPoints','Point','Trd','Point122-123'),(125,'Try3',1,'ThreadCenterLine','Line','Trd','1.1'),(126,'Try2',1,'Metrology','Circle','crl','9'),(127,'Try',1,'Metrology','Line','ssd','22'),(128,'Try',1,'Metrology','Line','ssd','23'),(129,'Try',1,'Metrology','Line','ssd','24'),(130,'Try',1,'StepLine','Line','ssd','23,24');
/*!40000 ALTER TABLE `measure_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:46
