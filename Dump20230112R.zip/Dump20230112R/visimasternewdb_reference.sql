-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reference`
--

DROP TABLE IF EXISTS `reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reference` (
  `ReferenceSEQID` int NOT NULL AUTO_INCREMENT,
  `JobNo` varchar(100) NOT NULL,
  `CamID` smallint NOT NULL,
  `ParameterName` varchar(100) NOT NULL,
  `RefJobNo` varchar(100) DEFAULT NULL,
  `RefCamID` smallint DEFAULT NULL,
  `RefParameterName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ReferenceSEQID`),
  KEY `References_Job_Parameter_idx` (`JobNo`,`CamID`,`ParameterName`),
  KEY `References_CamID_idx` (`CamID`),
  KEY `References_Ref_Job_Parameter_idx` (`RefJobNo`,`RefCamID`,`RefParameterName`),
  CONSTRAINT `References_CamID` FOREIGN KEY (`CamID`) REFERENCES `camera` (`CamID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `References_Job` FOREIGN KEY (`JobNo`) REFERENCES `job` (`JobNo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `References_Job_Parameter` FOREIGN KEY (`JobNo`, `CamID`, `ParameterName`) REFERENCES `job_parameter` (`JobNo`, `CamID`, `ParameterName`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `References_Ref_Job_Parameter` FOREIGN KEY (`RefJobNo`, `RefCamID`, `RefParameterName`) REFERENCES `job_parameter` (`JobNo`, `CamID`, `ParameterName`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Reference of dependent job parameter';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reference`
--

LOCK TABLES `reference` WRITE;
/*!40000 ALTER TABLE `reference` DISABLE KEYS */;
INSERT INTO `reference` VALUES (1,'12',1,'HexCircle415.75','12',1,'aaa'),(2,'RDN',1,'HexCircle463.75','RDN',1,'abc'),(3,'rtgt',1,'StepLine 1 2','rtgt',1,'rgte'),(4,'rtgt',1,'StepLine 4 5','rtgt',1,'rgte'),(5,'rtgt',1,'StepLine 6 7','rtgt',1,'rgte'),(6,'rtgt',1,'PeakLine 8','rtgt',1,'rgte'),(7,'rtgt',1,'Point58-55','rtgt',1,'rgte'),(8,'rtgt',1,'Point64-65','rtgt',1,'rgte'),(9,'Try',1,'StepLine 0 1','Try',1,'ssd'),(10,'Try',1,'StepLine 2 3','Try',1,'ssd'),(11,'Try',1,'Point74-73','Try',1,'ssd'),(12,'Try',1,'Point76-77','Try',1,'ssd'),(13,'Try',1,'PeakLine 8','Try',1,'ssd'),(14,'Try',1,'StepLine 9 10','Try',1,'ssd'),(15,'Try',1,'Point90-91','Try',1,'ssd'),(16,'123',1,'Point98-99','123',1,'square'),(17,'123',1,'Point96-97','123',1,'square'),(18,'123',1,'Point96-98','123',1,'square'),(19,'123',1,'Point99-97','123',1,'square'),(20,'123',1,'AngleIntesectionLine 4 5','123',1,'square'),(21,'Try',1,'Point107-108','Try',1,'ssd'),(22,'Try',1,'AngleIntesectionLine 18 19','Try',1,'ssd'),(23,'Try',1,'ThreadStartLine20','Try',1,'ssd'),(24,'Try',1,'ThreadStartLine21','Try',1,'ssd'),(25,'Try3',1,'StepLine 1 2','Try3',1,'Trd'),(26,'Try3',1,'PeakLine 3','Try3',1,'Trd'),(27,'Try3',1,'Point122-123','Try3',1,'Trd'),(28,'Try3',1,'ThreadCenterLine 1.1','Try3',1,'Trd'),(29,'Try',1,'StepLine 23 24','Try',1,'ssd');
/*!40000 ALTER TABLE `reference` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:45
