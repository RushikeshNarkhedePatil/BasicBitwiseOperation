-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `job_parameter`
--

DROP TABLE IF EXISTS `job_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_parameter` (
  `ParameterID` int NOT NULL AUTO_INCREMENT,
  `JobNo` varchar(100) NOT NULL,
  `CamID` smallint NOT NULL,
  `ParameterName` varchar(100) NOT NULL,
  `ParameterType` varchar(100) NOT NULL,
  `Master` double NOT NULL,
  `Positive` double NOT NULL,
  `Negative` double NOT NULL,
  `mmPix` double NOT NULL,
  `PixelValue` float NOT NULL,
  `LastUpdatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MeasuredValue` double NOT NULL,
  `ErrorValue` double NOT NULL DEFAULT '0',
  `ParameterGroupID` int NOT NULL DEFAULT '0',
  `Reference` varchar(100) DEFAULT NULL,
  `IsBackGroundParameter` tinyint DEFAULT '0',
  `IsReference` tinyint DEFAULT '0',
  `ResultSet` varchar(45) DEFAULT 'Default',
  `IsRotate` tinyint DEFAULT '0',
  `CriticalParameter` tinyint DEFAULT '0',
  `MeasuringInstruments` varchar(100) DEFAULT 'VisionMeasurement',
  PRIMARY KEY (`JobNo`,`CamID`,`ParameterName`),
  UNIQUE KEY `ParameterID_UNIQUE` (`ParameterID`),
  KEY `FK_JOBPARAM_CAMID` (`CamID`),
  CONSTRAINT `FK_JOBPARAM_CAMID` FOREIGN KEY (`CamID`) REFERENCES `camera` (`CamID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_JOBPARAM_JOBNO` FOREIGN KEY (`JobNo`) REFERENCES `job` (`JobNo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='job all parameter data';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_parameter`
--

LOCK TABLES `job_parameter` WRITE;
/*!40000 ALTER TABLE `job_parameter` DISABLE KEYS */;
INSERT INTO `job_parameter` VALUES (3,'1',1,'GD','TemplateMatching',1,1,0.8,1,1,'2022-08-16 09:49:28',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(4,'1',1,'SSsS','Surface',0,0,0,0,-1,'2022-08-16 09:49:51',0,1,0,NULL,NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(33,'12',1,'aaa','TemplateMatching',1,1,0.8,1,1,'2022-10-31 08:45:46',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(40,'12',1,'HexCircle415.75','AdvancedHexCircle',0,0,0,0,0,'2022-10-31 09:52:06',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(19,'12',2,'abc','TemplateMatching',1,1,0.8,1,1,'2022-10-31 06:29:51',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(98,'123',1,'Ang','Angle',87.37,89.37,85.37,0,87.37,'2022-11-01 11:00:13',87.37,0,0,'square',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(99,'123',1,'AngleIntesectionLine 4 5','AngleIntersectionLine',0,0,0,0,0,'2022-11-01 11:05:39',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(97,'123',1,'p2p','PointToPoint',22.505,22.555,22.455,0,22.505,'2022-11-01 10:50:04',22.505,0,0,'square',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(93,'123',1,'Point96-97','LinesIntersectionPoint',0,0,0,0,0,'2022-11-01 10:46:19',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(94,'123',1,'Point96-98','LinesIntersectionPoint',0,0,0,0,0,'2022-11-01 10:46:51',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(92,'123',1,'Point98-99','LinesIntersectionPoint',0,0,0,0,0,'2022-11-01 10:46:02',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(95,'123',1,'Point99-97','LinesIntersectionPoint',0,0,0,0,0,'2022-11-01 10:47:06',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(47,'123',1,'square','TemplateMatching',1,1,0.8,1,1,'2022-11-01 04:14:12',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(9,'a',1,'Profile','TemplateMatching',1,1,0.8,1,1,'2022-10-03 04:09:44',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(117,'demo11',1,'Profile','TemplateMatching',1,1,0.8,1,1,'2023-01-11 12:59:38',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(7,'g',1,'gb','TemplateMatching',1,1,0.8,1,1,'2022-08-18 09:51:26',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(8,'g',1,'sdfbg','Surface',0,0,0,0,-1,'2022-08-18 09:51:24',0,1,0,NULL,NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(6,'HRRR',2,'yjn','TemplateMatching',1,1,0.8,1,1,'2022-08-17 10:15:45',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(10,'hu',1,'vbhnvb','TemplateMatching',1,1,0.8,1,1,'2022-10-18 10:09:27',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(43,'NR',1,'ss','TemplateMatching',1,1,0.8,1,1,'2022-10-31 10:32:14',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(115,'prac',1,'Profile','TemplateMatching',1,1,0.8,1,1,'2023-01-09 09:03:30',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(55,'RDN',1,'abc','TemplateMatching',1,1,0.8,1,1,'2022-11-01 05:30:56',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(57,'RDN',1,'die','Diameter',1.714,1.764,1.664,0,1.714,'2022-11-01 05:34:15',1.714,0,0,'abc',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(56,'RDN',1,'diff','RadiusDiffrence',0.854,0.904,0.8039999999999999,0,0.854,'2022-11-01 05:32:18',0.854,0,0,'abc',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(58,'RDN',1,'HexCircle463.75','AdvancedHexCircle',0,0,0,0,0,'2022-11-01 05:39:23',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(41,'RN',1,'stamp','TemplateMatching',1,1,0.8,1,1,'2022-10-31 10:08:48',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(26,'RN',2,'ccc','TemplateMatching',1,1,0.8,1,1,'2022-10-31 07:27:56',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(59,'RN1',1,'abcd','TemplateMatching',1,1,0.8,1,1,'2022-11-01 06:06:09',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(67,'rtgt',1,'Default1','Angle',270.05,272.05,268.05,0,270.05,'2022-11-01 07:08:52',270.05,0,0,'rgte',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(68,'rtgt',1,'Default2','LineToLine',38.762,38.754,38.654,0,38.762,'2022-11-01 07:09:51',38.762,0,0,'rgte',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(61,'rtgt',1,'Defaulte','Diameter',1.499,1.5490000000000002,1.449,0,1.499,'2022-11-01 06:36:49',1.499,0,0,'rgte',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(62,'rtgt',1,'Defaultewd','Radius',0.749,0.799,0.699,0,0.749,'2022-11-01 06:37:16',0.749,0,0,'rgte',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(66,'rtgt',1,'PeakLine 8','PeakLine',0,0,0,0,0,'2022-11-01 07:06:01',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(69,'rtgt',1,'Point58-55','LinesIntersectionPoint',0,0,0,0,0,'2022-11-01 07:11:41',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(70,'rtgt',1,'Point64-65','LinesIntersectionPoint',0,0,0,0,0,'2022-11-01 07:19:16',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(60,'rtgt',1,'rgte','TemplateMatching',1,1,0.8,1,1,'2022-11-01 06:35:33',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(63,'rtgt',1,'StepLine 1 2','StepLine',0,0,0,0,0,'2022-11-01 06:42:32',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(64,'rtgt',1,'StepLine 4 5','StepLine',0,0,0,0,0,'2022-11-01 06:43:34',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(65,'rtgt',1,'StepLine 6 7','StepLine',0,0,0,0,0,'2022-11-01 06:44:09',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(116,'rushi',1,'profile','TemplateMatching',1,1,0.8,1,1,'2023-01-10 05:57:27',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(111,'TestingRN',1,'Profile','TemplateMatching',1,1,0.8,1,1,'2023-01-06 06:08:38',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(112,'TestingRN',2,'Profile','TemplateMatching',1,1,0.8,1,1,'2023-01-06 06:09:40',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(90,'Try',1,'ang','Angle',47.4,49.4,45.4,0,47.4,'2022-11-01 10:16:15',47.4,0,0,'ssd',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(82,'Try',1,'Angle','Angle',58.38,60.38,56.38,0,58.38,'2022-11-01 08:50:03',58.38,0,0,'ssd',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(101,'Try',1,'AngleIntesectionLine 18 19','AngleIntersectionLine',0,0,0,0,0,'2022-11-01 11:14:45',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(81,'Try',1,'die','Diameter',1.494,1.544,1.444,0,1.494,'2022-11-01 08:39:21',1.494,0,0,'ssd',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(80,'Try',1,'Line to Line','LineToLine',12.207,12.22,12.12,0,12.207,'2022-11-01 08:33:49',12.207,0,0,'ssd',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(75,'Try',1,'Line To Point','LineToPoint',18.599,18.649,18.549,0,18.599,'2022-11-01 08:15:10',18.599,0,0,'ssd',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(78,'Try',1,'PeakLine 8','PeakLine',0,0,0,0,0,'2022-11-01 08:29:51',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(77,'Try',1,'Point to Point','PointToPoint',8.375,8.425,8.325,0,8.375,'2022-11-01 08:27:06',8.375,0,0,'ssd',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(100,'Try',1,'Point107-108','LinesIntersectionPoint',0,0,0,0,0,'2022-11-01 11:13:51',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(74,'Try',1,'Point74-73','LinesIntersectionPoint',0,0,0,0,0,'2022-11-01 08:07:33',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(76,'Try',1,'Point76-77','LinesIntersectionPoint',0,0,0,0,0,'2022-11-01 08:25:21',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(89,'Try',1,'Point90-91','LinesIntersectionPoint',0,0,0,0,0,'2022-11-01 10:10:14',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(88,'Try',1,'re','Radius',0.762,0.812,0.712,0,0.762,'2022-11-01 10:04:22',0.762,0,0,'ssd',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(71,'Try',1,'ssd','TemplateMatching',1,1,0.8,1,1,'2022-11-01 07:24:33',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(72,'Try',1,'StepLine 0 1','StepLine',0,0,0,0,0,'2022-11-01 07:29:24',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(73,'Try',1,'StepLine 2 3','StepLine',0,0,0,0,0,'2022-11-01 07:56:16',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(113,'Try',1,'StepLine 23 24','StepLine',0,0,0,0,0,'2023-01-09 07:14:07',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(79,'Try',1,'StepLine 9 10','StepLine',0,0,0,0,0,'2022-11-01 08:32:41',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(103,'Try',1,'ThreadStartLine20','ThreadStartLine',0,0,0,0,0,'2022-11-01 11:46:58',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(104,'Try',1,'ThreadStartLine21','ThreadStartLine',0,0,0,0,0,'2022-11-01 11:50:03',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(91,'Try2',1,'AreaCenterPoint6','AreaCenterPoint',0,0,0,0,0,'2022-11-01 10:29:42',0,0,0,'crl',1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(102,'Try2',1,'AreaCenterPoint8','AreaCenterPoint',0,0,0,0,0,'2022-11-01 11:26:35',0,0,0,'crl',1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(83,'Try2',1,'crl','TemplateMatching',1,1,0.8,1,1,'2022-11-01 09:10:28',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement'),(84,'Try2',1,'die','Diameter',2.05,2.0999999999999996,1.9999999999999998,0,2.05,'2022-11-01 09:21:11',2.05,0,0,'crl',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(86,'Try2',1,'Radius','Radius',1.088,1.1380000000000001,1.038,0,1.088,'2022-11-01 09:44:32',1.088,0,0,'crl',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(87,'Try2',1,'Radius Difference','RadiusDiffrence',0.566,0.616,0.5159999999999999,0,0.566,'2022-11-01 09:52:45',0.566,0,0,'crl',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(108,'Try3',1,'PeakLine 3','PeakLine',0,0,0,0,0,'2022-11-01 12:03:48',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(109,'Try3',1,'Point122-123','LinesIntersectionPoint',0,0,0,0,0,'2022-11-01 12:08:20',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(106,'Try3',1,'Redius','Radius',0.727,0.777,0.6769999999999999,0,0.727,'2022-11-01 11:56:43',0.727,0,0,'Trd',NULL,NULL,'Default',NULL,NULL,'VisionMeasurement'),(107,'Try3',1,'StepLine 1 2','StepLine',0,0,0,0,0,'2022-11-01 11:59:39',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(110,'Try3',1,'ThreadCenterLine 1.1','ThreadCenterLine',0,0,0,0,0,'2022-11-01 12:17:36',0,0,0,NULL,1,NULL,'Default',NULL,NULL,'VisionMeasurement'),(105,'Try3',1,'Trd','TemplateMatching',1,1,0.8,1,1,'2022-11-01 11:54:09',1,0,0,'None',NULL,1,'Default',NULL,NULL,'VisionMeasurement');
/*!40000 ALTER TABLE `job_parameter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:45
