-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `module`
--

DROP TABLE IF EXISTS `module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `module` (
  `ModuleId` smallint NOT NULL AUTO_INCREMENT,
  `ModuleName` varchar(200) NOT NULL,
  `ParentModuleId` smallint DEFAULT NULL,
  `SortOrder` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ModuleId`),
  KEY `FK_Module_ParentModuleId_idx` (`ParentModuleId`),
  CONSTRAINT `FK_Module_ParentModuleId` FOREIGN KEY (`ParentModuleId`) REFERENCES `module` (`ModuleId`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module`
--

LOCK TABLES `module` WRITE;
/*!40000 ALTER TABLE `module` DISABLE KEYS */;
INSERT INTO `module` VALUES (59,'Dashboard',NULL,1),(60,'Reports',NULL,3),(61,'Settings',NULL,4),(62,'Teaching',NULL,2),(63,'Inspection',59,1),(64,'Window View',59,2),(65,'Add Windows',59,3),(66,'Quick Reports',59,4),(67,'Data Saving Operations',59,5),(68,'GRR',60,1),(69,'Printing',60,2),(70,'Export',60,3),(71,'Camera Setting',61,1),(72,'PLC Settings',61,2),(73,'Light Settings',61,3),(74,'Window Setting',61,4),(75,'General Settings',61,5),(76,'Motor Settings',61,6),(77,'Job',62,1),(78,'Capture',62,2),(79,'Setting Image',62,3),(80,'Matching',62,4),(81,'Measurement',62,5),(82,'Flaw/Defects',62,6),(83,'Other Setting',62,7),(84,'Select Part',63,1),(85,'Start Inspection',63,3),(86,'Stop Inspection',63,4),(87,'Quick View Template',64,1),(88,'Save User View',64,2),(89,'Load',64,3),(90,'Default View',64,4),(91,'Cumulative Result Window',65,1),(92,'Graphics Window',65,2),(93,'Result Window',65,3),(94,'Count Statistic',65,4),(95,'Time Statistic',65,5),(96,'Operation Window',65,6),(97,'Inspection Result Review',65,7),(98,'Production Report',66,1),(99,'Online SPC Chart',66,2),(100,'Sample Part Report',66,3),(101,'ManualSave Result',67,1),(102,'Batch Wise',67,2),(103,'DisplayDimensions',67,3),(104,'AutoSave Result',67,4),(105,'Print QR',67,5),(106,'Save Readings',67,8),(107,'GRR Settings',68,1),(108,'GRR Reports',68,2),(109,'Inprogress Inspection Report',68,3),(110,'Spc Report',68,4),(111,'Total Reports',68,5),(112,'PreDispatch Inspection Report',68,6),(113,'Daily Production Report',68,7),(114,'Print',69,1),(115,'Print Preview',69,2),(116,'Export To XLs',70,1),(117,'Export To PDF',70,2),(118,'Camera Configuration',71,1),(119,'Camera Manager',71,2),(120,'Image Setting',71,3),(121,'Camera Calibration',71,4),(122,'Load Calibration File',71,5),(123,'Part Calibration',71,6),(124,'Result Setting',72,1),(125,'PLC Configuration',72,2),(126,'PLC Register Setting',72,3),(127,'PLC Logic Setting',72,4),(128,'Control Settings',72,5),(129,'Light Controller Configuration',73,1),(130,'Light Controller Setting',73,2),(131,'Default Window',74,1),(132,'Save User Setting',74,2),(133,'Load',74,3),(134,'Add New User',75,1),(135,'Edit User',75,2),(136,'Remove User',75,3),(137,'System Type',75,4),(138,'Admin Setting',75,5),(139,'Report Setting',75,6),(140,'Master Part Setting',75,7),(141,'Alarm Setting',75,8),(142,'Access Rights Setting',75,9),(143,'Add User Shift',75,10),(144,'ScreenShot',75,12),(145,'InspectionPreferenceSetting',75,13),(146,'Motor Configuration',76,1),(147,'Start',76,2),(148,'Stop',76,3),(149,'Add Job',77,1),(150,'Edit Job',77,2),(151,'Remove Job',77,3),(152,'Start Camera',78,1),(153,'Stop Camera',78,2),(154,'Load',78,3),(155,'Save',78,4),(156,'Setting',78,5),(157,'Live On',78,6),(158,'Trigger On',78,7),(159,'Snap',78,8),(160,'Live',78,9),(161,'Stop',78,10),(162,'Calibration',78,11),(163,'Part Positioning',79,1),(164,'Light Setting',79,2),(165,'Focus Setting',79,3),(166,'Control Setting',79,4),(167,'Alignment',80,1),(168,'Matching',80,2),(169,'Default Layout',80,3),(170,'Auto Shape Detection',81,1),(171,'Auto Measurement',81,2),(172,'Manual Measurement',81,3),(173,'Special Parameters',81,4),(174,'Surface Defects',82,1),(175,'Edge Defects',82,2),(176,'Variation With Reference',82,3),(211,'Reference Line',83,1),(212,'Geometric Dimensions',173,1),(213,'Specific Dimensions',173,2),(214,'Thread',173,3),(215,'Dummy Parameters',173,4);
/*!40000 ALTER TABLE `module` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:44
