-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `productiondata`
--

DROP TABLE IF EXISTS `productiondata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productiondata` (
  `ProdDataSEQID` int NOT NULL AUTO_INCREMENT,
  `ParameterName` varchar(100) NOT NULL,
  `JobNo` varchar(100) NOT NULL,
  `CamID` smallint NOT NULL,
  `EmployeeID` varchar(45) NOT NULL,
  `CycleID` int NOT NULL,
  `ImageIndex` int NOT NULL,
  `MeasuredValue` double NOT NULL,
  `Status` tinyint NOT NULL,
  `LastUpdatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `BatchNo` int DEFAULT '0',
  `ResultStatus` tinyint NOT NULL DEFAULT '0',
  `MeasuringInstruments` varchar(100) DEFAULT NULL,
  `CriticalParameter` tinyint DEFAULT '0',
  PRIMARY KEY (`CycleID`,`CamID`,`JobNo`,`ParameterName`,`ImageIndex`),
  UNIQUE KEY `ProdDataSEQID_UNIQUE` (`ProdDataSEQID`),
  KEY `productiondataUserID_idx` (`EmployeeID`),
  KEY `productiondataJobNo_idx` (`JobNo`,`CamID`),
  KEY `FK_Job_Parameter_PName_CamID_JobNo_idx` (`JobNo`,`CamID`,`ParameterName`),
  KEY `FK_ProductionData_CAMID` (`CamID`),
  KEY `FK_ProductionData_ProductionCycle_idx` (`CycleID`),
  CONSTRAINT `FK_Job_Parameter_PName_CamID_JobNo` FOREIGN KEY (`JobNo`, `CamID`, `ParameterName`) REFERENCES `job_parameter` (`JobNo`, `CamID`, `ParameterName`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ProductionData_CAMID` FOREIGN KEY (`CamID`) REFERENCES `camera` (`CamID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ProductionData_JOBNO` FOREIGN KEY (`JobNo`) REFERENCES `job` (`JobNo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ProductionData_ProductionCycle` FOREIGN KEY (`CycleID`) REFERENCES `production_cycle` (`CycleID`),
  CONSTRAINT `FK_ProductionDataUserID` FOREIGN KEY (`EmployeeID`) REFERENCES `user` (`EmployeeID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='all parameter production data parameter wise';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productiondata`
--

LOCK TABLES `productiondata` WRITE;
/*!40000 ALTER TABLE `productiondata` DISABLE KEYS */;
INSERT INTO `productiondata` VALUES (1,'Profile','TestingRN',1,'987456321',58,1,1,1,'2023-01-06 06:55:01',0,1,NULL,NULL),(3,'Profile','TestingRN',1,'987456321',58,2,0.811,1,'2023-01-06 06:56:15',0,1,NULL,NULL),(2,'Profile','TestingRN',2,'987456321',58,1,0.999,1,'2023-01-06 06:55:35',0,1,NULL,NULL),(4,'Profile','TestingRN',2,'987456321',58,2,-2,0,'2023-01-06 06:56:39',0,0,NULL,NULL),(5,'Profile','TestingRN',2,'987456321',58,3,1,1,'2023-01-06 07:06:24',0,1,NULL,NULL),(6,'Profile','TestingRN',2,'987456321',58,4,-2,0,'2023-01-06 07:23:15',0,0,NULL,NULL),(7,'Profile','TestingRN',2,'987456321',58,5,-2,0,'2023-01-06 07:31:29',0,0,NULL,NULL),(8,'Profile','TestingRN',1,'987456321',59,5,0.814,1,'2023-01-06 08:25:31',0,1,NULL,NULL),(9,'Profile','TestingRN',1,'987456321',59,6,-2,0,'2023-01-06 08:29:42',0,0,NULL,NULL),(10,'Profile','TestingRN',1,'987456321',59,7,0.814,1,'2023-01-06 08:53:37',0,1,NULL,NULL),(11,'Profile','TestingRN',2,'987456321',59,7,-2,0,'2023-01-06 09:03:07',0,0,NULL,NULL),(12,'Profile','TestingRN',2,'987456321',59,8,1,1,'2023-01-06 09:04:21',0,1,NULL,NULL),(13,'Profile','TestingRN',2,'987456321',59,9,0.999,1,'2023-01-06 09:09:15',0,1,NULL,NULL),(14,'Profile','TestingRN',1,'987456321',60,9,1,1,'2023-01-06 09:11:12',0,1,NULL,NULL),(15,'Profile','TestingRN',2,'987456321',60,11,1,1,'2023-01-06 09:15:35',0,1,NULL,NULL),(16,'Profile','TestingRN',1,'987456321',72,1,1,1,'2023-01-06 11:17:08',0,1,NULL,NULL);
/*!40000 ALTER TABLE `productiondata` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:45
