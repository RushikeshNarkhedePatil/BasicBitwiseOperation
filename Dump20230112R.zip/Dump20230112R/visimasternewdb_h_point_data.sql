-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `h_point_data`
--

DROP TABLE IF EXISTS `h_point_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `h_point_data` (
  `SEQID` int NOT NULL AUTO_INCREMENT,
  `JobNo` varchar(100) NOT NULL,
  `CamID` smallint NOT NULL,
  `ParameterName` varchar(100) NOT NULL,
  `DataName` varchar(200) NOT NULL,
  `Row` double NOT NULL,
  `Column` double NOT NULL,
  `RefParameterName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`SEQID`),
  KEY `point_jobNo_Job_JobNo_idx` (`JobNo`,`CamID`,`ParameterName`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `h_point_data`
--

LOCK TABLES `h_point_data` WRITE;
/*!40000 ALTER TABLE `h_point_data` DISABLE KEYS */;
INSERT INTO `h_point_data` VALUES (1,'RN',1,'dia','TextPoint',-134.121568840316,2.435294478957019,'abc'),(2,'RDN',1,'die','TextPoint',174.33874029054277,108.64114615563352,'xyz'),(3,'RDN',1,'diff','TextPoint',92.94695438728262,210.86966735140624,'xyz'),(4,'RDN',1,'diff','TextPoint',-213.0586814401649,42.924158879755936,'abc'),(5,'RDN',1,'die','TextPoint',-104.94497339491127,160.01990057108034,'abc'),(6,'rtgt',1,'Defaulte','TextPoint',-80.33571338790284,60.382916050019105,'rgte'),(7,'rtgt',1,'Defaultewd','TextPoint',-30.000008641564023,46.000066805269,'rgte'),(8,'rtgt',1,'Default1','Point1',-132.79812840673026,-43.25133866257849,'rgte'),(9,'rtgt',1,'Default2','TextPoint',-52.33776523912195,1367.7691317955498,'rgte'),(10,'Try',1,'Line To Point','TextPoint',-54.94917435255479,1035.5597787675506,'ssd'),(11,'Try',1,'Point to Point','TextPoint',188.53948481387715,1283.2622625421097,'ssd'),(12,'Try',1,'Line to Line','TextPoint',244.81095882335944,-8.374246208231568,'ssd'),(13,'Try',1,'die','TextPoint',-86.84966925947288,23.12576192013495,'ssd'),(14,'Try',1,'Angle','Point1',-88.07709663917387,1325.4553404927008,'ssd'),(15,'Try2',1,'die','TextPoint',14.064009728001508,253.50649718020878,'crl'),(16,'Try2',1,'Radius','TextPoint',-199.2352308721368,333.28419541462193,'crl'),(17,'Try2',1,'Radius Difference','TextPoint',5.38026637240614,-148.36196692272452,'crl'),(18,'Try',1,'re','TextPoint',200.81466005152106,24.219854337715788,'ssd'),(19,'Try',1,'ang','Point1',204.70240237407484,1804.1311945850487,'ssd'),(20,'123',1,'P to P','TextPoint',106.22371953013408,319.99468459200693,'square'),(21,'123',1,'p2p','TextPoint',106.21859795214925,320.0129104825096,'square'),(22,'123',1,'Ang','Point1',-96.3460417486902,34.76998339571537,'square'),(23,'123',1,'AngleIntesectionLine 4 5','TextPoint',314.7756242094898,-106.90980263099209,'square'),(24,'123',1,'AngleIntesectionLine 4 5','Point1',-356.337723103131,-187.45075894373224,'square'),(25,'Try',1,'AngleIntesectionLine 18 19','Point1',222.7602220776023,1126.553565030854,'ssd'),(26,'Try3',1,'Redius','TextPoint',-135.50347400129522,-840.5821173470395,'Trd');
/*!40000 ALTER TABLE `h_point_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:46
