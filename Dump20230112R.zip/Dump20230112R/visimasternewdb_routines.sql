-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `group_module_access_rights`
--

DROP TABLE IF EXISTS `group_module_access_rights`;
/*!50001 DROP VIEW IF EXISTS `group_module_access_rights`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `group_module_access_rights` AS SELECT 
 1 AS `RowId`,
 1 AS `ModuleId`,
 1 AS `ModuleName`,
 1 AS `SortOrder`,
 1 AS `GroupId`,
 1 AS `HasAccess`,
 1 AS `TreeLevel`,
 1 AS `TreePath`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `group_module_access_rights`
--

/*!50001 DROP VIEW IF EXISTS `group_module_access_rights`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `group_module_access_rights` AS with recursive `module_path` (`ModuleId`,`ModuleName`,`SortOrder`,`GroupId`,`HasAccess`,`TreeLevel`,`TreePath`) as (select `m`.`ModuleId` AS `ModuleId`,`m`.`ModuleName` AS `ModuleName`,(`m`.`SortOrder` * pow(10,4)) AS `SortOrder`,`gm`.`GroupId` AS `GroupId`,`gm`.`HasAccess` AS `HasAccess`,0 AS `TreeLevel`,`m`.`ModuleName` AS `TreePath` from (`module` `m` left join `groupmodule` `gm` on((`gm`.`ModuleId` = `m`.`ModuleId`))) where (`m`.`ParentModuleId` is null) union all select `c`.`ModuleId` AS `ModuleId`,`c`.`ModuleName` AS `ModuleName`,(`cp`.`SortOrder` + (`c`.`SortOrder` * pow(10,(4 - (`cp`.`TreeLevel` + 1))))) AS `SortOrder`,`gmp`.`GroupId` AS `GroupId`,`gmp`.`HasAccess` AS `HasAccess`,(`cp`.`TreeLevel` + 1) AS `TreeLevel`,concat(`cp`.`TreePath`,' > ',`c`.`ModuleName`) AS `CONCAT(cp.TreePath, ' > ', c.ModuleName)` from ((`module_path` `cp` join `module` `c` on((`cp`.`ModuleId` = `c`.`ParentModuleId`))) left join `groupmodule` `gmp` on(((`gmp`.`ModuleId` = `c`.`ModuleId`) and ((`cp`.`TreeLevel` = 0) or ((`cp`.`TreeLevel` > 0) and (`cp`.`GroupId` = `gmp`.`GroupId`))))))) select row_number() OVER (ORDER BY `module_path`.`SortOrder` )  AS `RowId`,`module_path`.`ModuleId` AS `ModuleId`,`module_path`.`ModuleName` AS `ModuleName`,`module_path`.`SortOrder` AS `SortOrder`,`module_path`.`GroupId` AS `GroupId`,`module_path`.`HasAccess` AS `HasAccess`,`module_path`.`TreeLevel` AS `TreeLevel`,`module_path`.`TreePath` AS `TreePath` from `module_path` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'visimasternewdb'
--

--
-- Dumping routines for database 'visimasternewdb'
--
/*!50003 DROP PROCEDURE IF EXISTS `DynamicReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DynamicReport`(in selectedOption varchar(50),in QJobNo varchar(50), in QStartDate datetime,in  QEndDate datetime,in QResultStatus TINYINT,in QCycleId int,in QBatchNo int)
BEGIN 
set @QselectedOption=selectedOption;
set @QJobNo=QJobNo;
set @QStartDate=QStartDate;
set @QEndDate=QEndDate;
set @QResultStatus=QResultStatus;
set @QCycleId=QCycleId;
set @QBatchNo=QBatchNo;

 if( @QselectedOption='ByDateWise') then
   drop table if exists  tempdata;
     set @group ='CREATE temporary table  IF NOT EXISTS tempdata (SELECT DISTINCT JobID,jb.JobNo, prd.ParameterName,prd.ResultStatus,prd.CamID, prd.MeasuredValue, prd.CycleID,prd.ImageIndex,prd.LastUpdatedDate  FROM visimasternewdb.job  as jd
    inner join job_parameter as jb on jd.JobNo=jb.JobNo
    inner join productiondata as prd on jb.ParameterName=prd.ParameterName 
    where jb.ParameterName=prd.ParameterName   and jd.JobNo=prd.jobNo and  prd.JobNo=@QJobNo  and  prd.LastUpdatedDate >= @QStartDate and  prd.LastUpdatedDate <= @QEndDate 
   order by prd.CycleID )';
   
   elseif ( @QselectedOption='ByBatchWise') then
      drop table if exists  tempdata;
        set @group ='CREATE temporary table  IF NOT EXISTS tempdata (SELECT DISTINCT JobID,jb.JobNo, prd.ParameterName,
         prd.ResultStatus,prd.CamID, prd.MeasuredValue, prd.CycleID,prd.ImageIndex,prd.LastUpdatedDate  FROM visimasternewdb.job  as jd
          inner join job_parameter as jb on jd.JobNo=jb.JobNo
          inner join productiondata as prd on jb.ParameterName=prd.ParameterName 
            where jb.ParameterName=prd.ParameterName   and jd.JobNo=prd.jobNo and  prd.JobNo=@QJobNo  and 
           prd.LastUpdatedDate >= @QStartDate and  prd.LastUpdatedDate <= @QEndDate and prd.CycleID=@QCycleId and prd.BatchNo=@QBatchNo
             )';      
   else   
     drop table if exists  tempdata;
    set @group ='CREATE temporary table  IF NOT EXISTS tempdata (SELECT DISTINCT JobID,jb.JobNo, prd.ParameterName,
    prd.ResultStatus,prd.CamID, prd.MeasuredValue, prd.CycleID,prd.ImageIndex,prd.LastUpdatedDate  FROM visimasternewdb.job  as jd
    inner join job_parameter as jb on jd.JobNo=jb.JobNo
    inner join productiondata as prd on jb.ParameterName=prd.ParameterName 
    where jb.ParameterName=prd.ParameterName   and jd.JobNo=prd.jobNo and  prd.JobNo=@QJobNo  and 
     prd.LastUpdatedDate >= @QStartDate and  prd.LastUpdatedDate <= @QEndDate and prd.CycleID=@QCycleId 
    )';
  end if;

Prepare stmt1 FROM @group;  
EXECUTE stmt1;
 
 if((select count(*) from tempdata) =0) then 
  select count(*) from tempdata;
else

   drop table if exists  ResultStatusNOK;
CREATE temporary table  IF NOT EXISTS ResultStatusNOK (
select DISTINCT CycleID,ImageIndex from tempdata where ResultStatus=0);

SET SESSION group_concat_max_len = 1000000;
SET @sql = NULL;
SELECT 
  GROUP_CONCAT( DISTINCT  
  CONCAT('MAX(IF(`ParameterName` = "', `ParameterName`,'" and `CamID` = "', `CamID`,'", `MeasuredValue`,"")) AS "',`ParameterName`,'"' )    
  ) INTO @sql
FROM tempdata ;
   
if(@QResultStatus=0) then
     SET @sql = CONCAT('SELECT `LastUpdatedDate`,  ', @sql, ' 
                  FROM tempdata s where 
                   s.imageindex  IN (SELECT imageindex from ResultStatusNOK where CycleID=s.CycleID  GROUP BY ImageIndex  , CycleID )
				GROUP BY s.`ImageIndex`  , s.`CycleID`
                  ORDER BY s.`CycleID` , s.`imageindex`
				');
elseif(@QResultStatus=1) then
  SET @sql = CONCAT('SELECT `LastUpdatedDate`,  ', @sql, ' 
                  FROM tempdata s where                
                  s.imageindex NOT IN (SELECT imageindex from ResultStatusNOK where CycleID=s.CycleID  GROUP BY ImageIndex  , CycleID )
                  
                  GROUP BY s.`ImageIndex`  , s.`CycleID`
                  ORDER BY s.`CycleID` , s.`imageindex`
				');             
 else
   SET @sql = CONCAT('SELECT `LastUpdatedDate`,  ', @sql, ' 
                  FROM tempdata s                   
                  GROUP BY s.`ImageIndex`  , s.`CycleID`
                  ORDER BY s.`CycleID` , s.`imageindex`
				');
end  if;       
#SELECT @sql;
PREPARE stmt FROM @sql;
EXECUTE stmt;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DynamicReportStationWise` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DynamicReportStationWise`(in selectedOption varchar(50),in QJobNo varchar(50), in QStartDate datetime,in  QEndDate datetime,in QResultStatus TINYINT,in QCycleId int,in QBatchNo int,in selectedResultStation varchar(50))
BEGIN 
set @QselectedOption=selectedOption;
set @QJobNo=QJobNo;
set @QStartDate=QStartDate;
set @QEndDate=QEndDate;
set @QResultStatus=QResultStatus;
set @QCycleId=QCycleId;
set @QBatchNo=QBatchNo;
set @QselectedResultStation=selectedResultStation;

 if( @QselectedOption='ByDateWise') then
   drop table if exists  tempdata1;
     set @group ='CREATE temporary table  IF NOT EXISTS tempdata1 (SELECT DISTINCT JobID,jb.JobNo, prd.ParameterName,prd.ResultStatus,prd.CamID, prd.MeasuredValue, prd.CycleID,prd.ImageIndex,prd.LastUpdatedDate  FROM visimasternewdb.job  as jd
    inner join job_parameter as jb on jd.JobNo=jb.JobNo
    inner join productiondata as prd on jb.ParameterName=prd.ParameterName 
    where jb.ParameterName=prd.ParameterName   and jd.JobNo=prd.jobNo and  prd.JobNo=@QJobNo  and  prd.LastUpdatedDate >= @QStartDate and  prd.LastUpdatedDate <= @QEndDate and prd.CamID in (select CameraID from result_combination where ResultSet=@QselectedResultStation)
   order by prd.CycleID )';
   
   elseif ( @QselectedOption='ByBatchWise') then
      drop table if exists  tempdata1;
        set @group ='CREATE temporary table  IF NOT EXISTS tempdata1 (SELECT DISTINCT JobID,jb.JobNo, prd.ParameterName,
         prd.ResultStatus,prd.CamID, prd.MeasuredValue, prd.CycleID,prd.ImageIndex,prd.LastUpdatedDate  FROM visimasternewdb.job  as jd
          inner join job_parameter as jb on jd.JobNo=jb.JobNo
          inner join productiondata as prd on jb.ParameterName=prd.ParameterName 
            where jb.ParameterName=prd.ParameterName   and jd.JobNo=prd.jobNo and  prd.JobNo=@QJobNo  and 
           prd.LastUpdatedDate >= @QStartDate and  prd.LastUpdatedDate <= @QEndDate and prd.CycleID=@QCycleId and prd.BatchNo=@QBatchNo and prd.CamID in (select CameraID from result_combination where ResultSet=@QselectedResultStation)
             )';      
   else   
     drop table if exists  tempdata1;
    set @group ='CREATE temporary table  IF NOT EXISTS tempdata1 (SELECT DISTINCT JobID,jb.JobNo, prd.ParameterName,
    prd.ResultStatus,prd.CamID, prd.MeasuredValue, prd.CycleID,prd.ImageIndex,prd.LastUpdatedDate  FROM visimasternewdb.job  as jd
    inner join job_parameter as jb on jd.JobNo=jb.JobNo
    inner join productiondata as prd on jb.ParameterName=prd.ParameterName 
    where jb.ParameterName=prd.ParameterName   and jd.JobNo=prd.jobNo and  prd.JobNo=@QJobNo  and 
     prd.LastUpdatedDate >= @QStartDate and  prd.LastUpdatedDate <= @QEndDate and prd.CycleID=@QCycleId and prd.CamID in (select CameraID from result_combination where ResultSet=@QselectedResultStation)
    )';
  end if;

Prepare stmt1 FROM @group;  
EXECUTE stmt1;
 

 if((select count(*) from tempdata1) =0) then 
  select count(*) from tempdata1;
else

   drop table if exists  ResultStatusNOK1;
CREATE temporary table  IF NOT EXISTS ResultStatusNOK1 (
select DISTINCT CycleID,ImageIndex from tempdata1 where ResultStatus=0);


SET SESSION group_concat_max_len = 1000000;

SET @sql = NULL;

SELECT 
  GROUP_CONCAT( DISTINCT  
  CONCAT('MAX(IF(`ParameterName` = "', `ParameterName`,'" and `CamID` = "', `CamID`,'", `MeasuredValue`,"")) AS "',`ParameterName`,'"' )    
  ) INTO @sql
FROM tempdata1 ;

   
if(@QResultStatus=0) then
     SET @sql = CONCAT('SELECT `LastUpdatedDate`,  ', @sql, ' 
                  FROM tempdata1 s where 
                   s.imageindex  IN (SELECT imageindex from ResultStatusNOK1 where CycleID=s.CycleID  GROUP BY ImageIndex  , CycleID )
				GROUP BY s.`ImageIndex`  , s.`CycleID`
                  ORDER BY s.`CycleID` , s.`imageindex`
				');
                
elseif(@QResultStatus=1) then
  SET @sql = CONCAT('SELECT `LastUpdatedDate`,  ', @sql, ' 
                  FROM tempdata1 s where                
                  s.imageindex NOT IN (SELECT imageindex from ResultStatusNOK1 where CycleID=s.CycleID  GROUP BY ImageIndex  , CycleID )
                  
                  GROUP BY s.`ImageIndex`  , s.`CycleID`
                  ORDER BY s.`CycleID` , s.`imageindex`
				');
                
 else
   SET @sql = CONCAT('SELECT `LastUpdatedDate`,  ', @sql, ' 
                  FROM tempdata1 s                   
                  GROUP BY s.`ImageIndex`  , s.`CycleID`
                  ORDER BY s.`CycleID` , s.`imageindex`
				');
end  if;
                       
                
#SELECT @sql;
PREPARE stmt FROM @sql;
EXECUTE stmt;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetInspectionRpt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetInspectionRpt`(IN JobNo varchar(50))
BEGIN

CREATE TEMPORARY TABLE IF NOT EXISTS OkCounts AS
(select  CycleID,ImageIndex, count(parametername) as Parametercount,
sum(case when ifnull(status,0) = 1 then 1 else 0 end) as 'OKcount',
sum(case when ifnull(status,0) = 0 then 1 else 0 end) as 'NOKcount' from productiondata 
where JobNo=JobNo group by CycleID,ImageIndex);

CREATE TEMPORARY TABLE IF NOT EXISTS SumOkCounts AS
select oc.cycleid,sum(case when (Parametercount = OKcount) then 1 else 0 end) ok ,
sum(case when (Parametercount <> OKcount) then 1 else 0 end)  as nok from OkCounts oc
 group by CycleID;

select j.JobNo,j.JobName,pd.LastUpdatedDate, 
u.UserName, oc.cycleid,oc.ok as OK,  oc.nok as Notok from SumOkCounts oc
left join productiondata pd on pd.CycleID = oc.CycleID 
Left join job j On pd.JobNo =  j.JobNo
Left join production_cycle pc on pd.CycleID = pc.CycleID
left join user u on pd.EmployeeID = u.EmployeeID 
where pd.jobno =JobNo
group by oc.cycleid;

drop table OkCounts;
drop table SumOkCounts;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetInspectionRptDatewise` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetInspectionRptDatewise`(IN JobNo varchar(50),in FromDate datetime,in Todate datetime)
BEGIN
CREATE TEMPORARY TABLE IF NOT EXISTS OkCounts AS
(select  CycleID,ImageIndex, count(parametername) as Parametercount,
sum(case when ifnull(status,0) = 1 then 1 else 0 end) as 'OKcount',
sum(case when ifnull(status,0) = 0 then 1 else 0 end) as 'NOKcount' from productiondata 
where JobNo=JobNo and LastUpdatedDate>=FromDate and LastUpdatedDate<=Todate  group by CycleID,ImageIndex);

CREATE TEMPORARY TABLE IF NOT EXISTS SumOkCounts AS
select oc.cycleid,sum(case when (Parametercount = OKcount) then 1 else 0 end) ok ,
sum(case when (Parametercount <> OKcount) then 1 else 0 end)  as nok from OkCounts oc
 group by CycleID;

select j.JobNo,j.JobName,pd.LastUpdatedDate, 
u.UserName, oc.cycleid,oc.ok as OK,  oc.nok as Notok from SumOkCounts oc
left join productiondata pd on pd.CycleID = oc.CycleID 
Left join job j On pd.JobNo =  j.JobNo
Left join production_cycle pc on pd.CycleID = pc.CycleID
left join user u on pd.EmployeeID = u.EmployeeID 
where pd.jobno =JobNo
group by oc.cycleid;

drop table OkCounts;
drop table SumOkCounts;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InspectionCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `InspectionCount`(IN JobNo varchar(50))
BEGIN
SELECT row_number() OVER (ORDER BY CycleID,PD.parametername) As Nos,
cycleid,PD.parametername,  CameraName, Master,Negative, Positive,
sum(case when ifnull(status,0) = 0 then 0 else 1 end)  as 'OK',
sum(case when ifnull(status,0) = 0 then 1 else 0 end)  as 'NOTOK' 
FROM visimasternewdb.productiondata PD
left join camera c on pd.CamID = c.CamID
Left Join job_parameter JP ON (PD.ParameterName = jp.ParameterName AND PD.JobNo = jp.JobNo)
where PD.jobno=JobNo
group by CycleID,PD.parametername;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InspectionCountDatewise` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `InspectionCountDatewise`(IN JobNo varchar(50),in FromDate datetime,in Todate datetime)
BEGIN
SELECT row_number() OVER (ORDER BY CycleID,PD.parametername) As Nos,
cycleid,PD.parametername,  CameraName, Master,Negative, Positive,
sum(case when ifnull(status,0) = 0 then 0 else 1 end)  as 'OK',
sum(case when ifnull(status,0) = 0 then 1 else 0 end)  as 'NOTOK' 
FROM visimasternewdb.productiondata PD
left join camera c on pd.CamID = c.CamID
Left Join job_parameter JP ON (PD.ParameterName = jp.ParameterName AND PD.JobNo = jp.JobNo)
where PD.jobno=JobNo and PD. LastUpdatedDate>=FromDate and PD.LastUpdatedDate<=Todate
group by CycleID,PD.parametername;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SaveProductionData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`system1`@`localhost` PROCEDURE `SaveProductionData`(
IN ParameterName  varchar(100) ,
IN JobNo varchar(100) ,
IN CamID smallint,
IN EmployeeID varchar(45),
IN CycleID int,
IN ImageIndex int,
IN MeasuredValue double,
IN Statuss  TINYINT,
IN BatchNo int,
IN ResultStatus TINYINT,
IN MeasuringInstruments  varchar(100) ,
IN CriticalParameter TINYINT
)
BEGIN 
		insert into productiondata(`ParameterName`,`JobNo`,`CamID`,`EmployeeID`,`CycleID`,`ImageIndex`,`MeasuredValue`,`Status`,`BatchNo`,`ResultStatus`,`MeasuringInstruments`,`CriticalParameter`) values(ParameterName,JobNo,CamID,EmployeeID,CycleID,ImageIndex,MeasuredValue,Statuss,BatchNo,ResultStatus,MeasuringInstruments,CriticalParameter);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:49
