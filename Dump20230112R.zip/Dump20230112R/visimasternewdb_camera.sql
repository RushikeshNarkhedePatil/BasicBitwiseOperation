-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: visimasternewdb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `camera`
--

DROP TABLE IF EXISTS `camera`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `camera` (
  `CamID` smallint NOT NULL,
  `SerialNo` varchar(50) DEFAULT NULL,
  `CameraName` varchar(45) DEFAULT NULL,
  `Manufacturer` varchar(100) DEFAULT NULL,
  `Model` varchar(100) DEFAULT NULL,
  `OriginalImageWidth` smallint NOT NULL,
  `OriginalImageHeight` smallint NOT NULL,
  `StartRow` smallint DEFAULT '0',
  `StartColomn` smallint DEFAULT '0',
  `ImageWidth` smallint DEFAULT '0',
  `ImageHeight` smallint DEFAULT '0',
  `PixelClock` smallint DEFAULT NULL,
  `FrameRate` float DEFAULT '8',
  `ExposureTime` float DEFAULT NULL,
  `Gain` int DEFAULT NULL,
  `IsGainBoost` tinyint DEFAULT '0',
  `BlackLavel` smallint DEFAULT NULL,
  `IsBlackLavelAuto` tinyint DEFAULT '1',
  `PixelFormat` varchar(45) DEFAULT NULL,
  `TriggerDelay` int DEFAULT '0',
  `IsTriggerActive` tinyint DEFAULT '0',
  `TriggerMode` varchar(45) DEFAULT NULL,
  `TriggerTimeOut` int DEFAULT NULL,
  `DebounceMode` varchar(45) DEFAULT NULL,
  `DebounceDelayTime` int DEFAULT '1',
  `PrescalerFrame` smallint DEFAULT NULL,
  `PrescalerLine` smallint DEFAULT NULL,
  `FlashOutPut` varchar(45) DEFAULT NULL,
  `FlashDelay` int DEFAULT NULL,
  `FlashDuration` int DEFAULT NULL,
  `GPIO` varchar(45) DEFAULT NULL,
  `GPIOConfig` varchar(45) DEFAULT NULL,
  `LastUpdatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`CamID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Camera details';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `camera`
--

LOCK TABLES `camera` WRITE;
/*!40000 ALTER TABLE `camera` DISABLE KEYS */;
INSERT INTO `camera` VALUES (1,'19299146','Top','FLIR','19299146',2048,1536,0,0,0,0,NULL,8,NULL,NULL,0,NULL,1,NULL,0,0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-08-16 09:12:26'),(2,'19299153','Bottom','FLIR','19299153',2048,1536,0,0,0,0,NULL,8,NULL,NULL,0,NULL,1,NULL,0,0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-08-16 09:12:26');
/*!40000 ALTER TABLE `camera` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 12:25:47
